// backend/server.js - VERSÃO COMPLETA COM PROFISSIONAIS
const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = 3000;

// ==================== ROTAS DE AGENDAMENTOS ====================
app.get('/api/agendamentos/estatisticas/hoje', (req, res) => {
    console.log('[API] Recebida requisição para /api/agendamentos/estatisticas/hoje');
    
    try {
        const db = require('../database/db');
        const hoje = new Date().toISOString().split('T')[0];
        
        console.log(`[API] Buscando agendamentos para hoje: ${hoje}`);
        
        // CONSULTA 1: Estatísticas gerais do dia
        const sqlEstatisticas = `
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN status = 'confirmado' THEN 1 ELSE 0 END) as confirmados,
                SUM(CASE WHEN status = 'pendente' THEN 1 ELSE 0 END) as pendentes,
                SUM(CASE WHEN status = 'cancelado' THEN 1 ELSE 0 END) as cancelados,
                SUM(CASE WHEN status = 'concluido' THEN 1 ELSE 0 END) as concluidos,
                SUM(CASE WHEN pago = 1 THEN valor_final ELSE 0 END) as receita_confirmada,
                SUM(valor_final) as receita_estimada_total,
                SUM(gorjeta) as gorjeta_total
            FROM agendamentos 
            WHERE DATE(data_agendamento) = ?
        `;
        
        db.get(sqlEstatisticas, [hoje], (err, estatisticas) => {
            if (err) {
                console.error('[API] Erro na consulta de estatísticas:', err);
                return res.status(500).json({ 
                    error: 'Erro no banco de dados',
                    detalhes: err.message 
                });
            }
            
            // Se não encontrou agendamentos hoje
            if (!estatisticas.total) {
                estatisticas = {
                    total: 0,
                    confirmados: 0,
                    pendentes: 0,
                    cancelados: 0,
                    concluidos: 0,
                    receita_confirmada: 0,
                    receita_estimada_total: 0,
                    gorjeta_total: 0
                };
            }
            
            // CONSULTA 2: Agendamentos detalhados do dia
            const sqlAgendamentos = `
                SELECT 
                    a.id,
                    a.data_agendamento,
                    a.status,
                    a.valor_final,
                    a.valor_servico,
                    a.desconto_aplicado,
                    a.gorjeta,
                    a.pago,
                    a.observacoes,
                    c.nome_completo as cliente_nome,
                    c.telefone as cliente_telefone,
                    s.nome as servico_nome,
                    p.nome_completo as profissional_nome,
                    p.especialidade as profissional_especialidade
                FROM agendamentos a
                LEFT JOIN clientes c ON a.cliente_id = c.id
                LEFT JOIN servicos s ON a.servico_id = s.id
                LEFT JOIN profissionais p ON a.profissional_id = p.id
                WHERE DATE(a.data_agendamento) = ?
                ORDER BY a.data_agendamento ASC
                LIMIT 20
            `;
            
            db.all(sqlAgendamentos, [hoje], (err2, agendamentosDetalhados) => {
                if (err2) {
                    console.error('[API] Erro na consulta de detalhes:', err2);
                    // Retornar só as estatísticas se der erro nos detalhes
                    return res.json({
                        ...estatisticas,
                        agendamentos: [],
                        mensagem: 'Estatísticas carregadas, detalhes com erro'
                    });
                }
                
                // CONSULTA 3: Distribuição por profissional
                const sqlProfissionais = `
                    SELECT 
                        p.nome_completo,
                        p.especialidade,
                        COUNT(a.id) as total_agendamentos,
                        SUM(a.valor_final) as valor_total
                    FROM agendamentos a
                    LEFT JOIN profissionais p ON a.profissional_id = p.id
                    WHERE DATE(a.data_agendamento) = ?
                    GROUP BY p.id, p.nome_completo
                    ORDER BY total_agendamentos DESC
                `;
                
                db.all(sqlProfissionais, [hoje], (err3, porProfissional) => {
                    if (err3) {
                        console.error('[API] Erro na consulta por profissional:', err3);
                        porProfissional = [];
                    }
                    
                    // CONSULTA 4: Distribuição por horário
                    const sqlHorarios = `
                        SELECT 
                            strftime('%H:00', a.data_agendamento) as hora,
                            COUNT(*) as quantidade,
                            SUM(a.valor_final) as valor_total
                        FROM agendamentos a
                        WHERE DATE(a.data_agendamento) = ?
                        GROUP BY strftime('%H', a.data_agendamento)
                        ORDER BY hora
                    `;
                    
                    db.all(sqlHorarios, [hoje], (err4, porHorario) => {
                        if (err4) {
                            console.error('[API] Erro na consulta por horário:', err4);
                            porHorario = [];
                        }
                        
                        // Formatar resposta final
                        const resposta = {
                            ...estatisticas,
                            data_consulta: hoje,
                            agendamentos: agendamentosDetalhados || [],
                            distribuicao_profissionais: porProfissional || [],
                            distribuicao_horarios: porHorario || [],
                            proximos_agendamentos: agendamentosDetalhados
                                .filter(a => a.status === 'confirmado' || a.status === 'pendente')
                                .slice(0, 5)
                        };
                        
                        console.log(`[API] Estatísticas encontradas: ${estatisticas.total} agendamentos para hoje`);
                        console.log(`[API] Receita estimada: R$ ${estatisticas.receita_estimada_total || 0}`);
                        
                        res.json(resposta);
                    });
                });
            });
        });
    } catch (error) {
        console.error('[API] Erro geral no endpoint:', error);
        res.status(500).json({ 
            error: 'Erro interno do servidor',
            detalhes: error.message,
            mensagem: 'Por favor, tente novamente mais tarde'
        });
    }
});

// ===== MIDDLEWARES =====
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Logging
app.use((req, res, next) => {
    console.log(`${new Date().toLocaleTimeString()} ${req.method} ${req.url}`);
    next();
});

// ===== CONEXÃO COM BANCO =====
const db = require('../database/db');
console.log('✅ Módulo do banco carregado: ../database/db.js');

// Verificar arquivo do banco
const dbFilePath = path.join(__dirname, '../salao.db');
if (!fs.existsSync(dbFilePath)) {
    console.warn('⚠️  Arquivo salao.db não encontrado');
    console.log('💡 Execute: npm run init-db para criar o banco');
} else {
    console.log('💾 Banco de dados encontrado: salao.db');
}

// ===== ROTAS DA API =====

// Health Check
app.get('/api/health', (req, res) => {
    res.json({
        status: 'ok',
        message: 'API My Salon está funcionando',
        timestamp: new Date().toISOString(),
        database: fs.existsSync(dbFilePath) ? 'connected' : 'file_not_found',
        endpoints: {
            clientes: '/api/clientes',
            servicos: '/api/servicos',
            profissionais: '/api/profissionais',
            health: '/api/health'
        }
    });
});

// ===== ROTAS DE CLIENTES =====

// GET /api/clientes - Listar todos os clientes
app.get('/api/clientes', (req, res) => {
    const { search, status } = req.query;
    
    let sql = 'SELECT * FROM clientes WHERE 1=1';
    const params = [];
    
    if (search) {
        sql += ' AND (nome_completo LIKE ? OR telefone LIKE ? OR email LIKE ?)';
        params.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }
    
    if (status && status !== 'todos') {
        sql += ' AND status = ?';
        params.push(status);
    }
    
    sql += ' ORDER BY nome_completo';
    
    db.all(sql, params, (err, rows) => {
        if (err) {
            console.error('Erro ao buscar clientes:', err.message);
            res.status(500).json({ 
                success: false, 
                error: err.message 
            });
        } else {
            res.json({ 
                success: true, 
                data: rows,
                total: rows.length 
            });
        }
    });
});

// GET /api/clientes/:id - Buscar cliente por ID
app.get('/api/clientes/:id', (req, res) => {
    const { id } = req.params;
    
    db.get('SELECT * FROM clientes WHERE id = ?', [id], (err, row) => {
        if (err) {
            res.status(500).json({ success: false, error: err.message });
        } else if (row) {
            res.json({ success: true, data: row });
        } else {
            res.status(404).json({ success: false, error: 'Cliente não encontrado' });
        }
    });
});

// POST /api/clientes - Criar novo cliente
app.post('/api/clientes', (req, res) => {
    const cliente = req.body;
    
    if (!cliente.nome_completo || !cliente.telefone) {
        return res.status(400).json({ 
            success: false, 
            error: 'Nome e telefone são obrigatórios' 
        });
    }
    
    const sql = `INSERT INTO clientes (
        nome_completo, telefone, email, data_nascimento, 
        genero, status, observacoes, pontos_fidelidade, data_cadastro
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))`;
    
    const params = [
        cliente.nome_completo,
        cliente.telefone,
        cliente.email || '',
        cliente.data_nascimento || '',
        cliente.genero || '',
        cliente.status || 'ativo',
        cliente.observacoes || '',
        cliente.pontos_fidelidade || 0
    ];
    
    db.run(sql, params, function(err) {
        if (err) {
            console.error('Erro ao criar cliente:', err.message);
            res.status(500).json({ success: false, error: err.message });
        } else {
            res.status(201).json({ 
                success: true, 
                message: 'Cliente criado com sucesso',
                id: this.lastID 
            });
        }
    });
});

// PUT /api/clientes/:id - Atualizar cliente
app.put('/api/clientes/:id', (req, res) => {
    const { id } = req.params;
    const cliente = req.body;
    
    const sql = `UPDATE clientes SET 
        nome_completo = ?, telefone = ?, email = ?, data_nascimento = ?,
        genero = ?, status = ?, observacoes = ?, pontos_fidelidade = ?,
        data_ultima_visita = datetime('now')
        WHERE id = ?`;
    
    const params = [
        cliente.nome_completo,
        cliente.telefone,
        cliente.email || '',
        cliente.data_nascimento || '',
        cliente.genero || '',
        cliente.status || 'ativo',
        cliente.observacoes || '',
        cliente.pontos_fidelidade || 0,
        id
    ];
    
    db.run(sql, params, function(err) {
        if (err) {
            res.status(500).json({ success: false, error: err.message });
        } else if (this.changes === 0) {
            res.status(404).json({ success: false, error: 'Cliente não encontrado' });
        } else {
            res.json({ 
                success: true, 
                message: 'Cliente atualizado com sucesso' 
            });
        }
    });
});

// DELETE /api/clientes/:id - Inativar cliente
app.delete('/api/clientes/:id', (req, res) => {
    const { id } = req.params;
    
    const sql = `UPDATE clientes SET status = 'inativo' WHERE id = ?`;
    
    db.run(sql, [id], function(err) {
        if (err) {
            res.status(500).json({ success: false, error: err.message });
        } else if (this.changes === 0) {
            res.status(404).json({ success: false, error: 'Cliente não encontrado' });
        } else {
            res.json({ 
                success: true, 
                message: 'Cliente inativado com sucesso' 
            });
        }
    });
});

// ===== ROTAS DE SERVIÇOS =====
const servicosRouter = require('./routes/servicos');
app.use('/api/servicos', servicosRouter);

// ===== ROTAS DE PROFISSIONAIS =====
// CORREÇÃO: Verificar se o arquivo existe antes de carregar
try {
    const profissionaisRouter = require('./routes/profissionais');
    app.use('/api/profissionais', profissionaisRouter);
    console.log('✅ Rotas de profissionais carregadas');
} catch (error) {
    console.warn('⚠️  Arquivo de rotas de profissionais não encontrado');
    console.log('💡 Criando rotas básicas para profissionais...');
    
    // Criar rotas básicas para profissionais se o arquivo não existir
    const basicProfissionaisRouter = express.Router();
    
    // Health check para profissionais
    basicProfissionaisRouter.get('/test/health', (req, res) => {
        res.json({
            status: 'ok',
            message: 'API Profissionais funcionando',
            timestamp: new Date().toISOString(),
            note: 'Using basic routes (arquivo profissionais.js não encontrado)'
        });
    });
    
    // Listar profissionais (dados de exemplo)
    basicProfissionaisRouter.get('/', (req, res) => {
        const { status } = req.query;
        
        let sql = 'SELECT id, nome, especialidade, telefone, email, status, cpf, funcao, comissao FROM profissionais WHERE 1=1';
        const params = [];
        
        if (status) {
            sql += ' AND status = ?';
            params.push(status);
        }
        
        sql += ' ORDER BY nome ASC';
        
        db.all(sql, params, (err, rows) => {
            if (err) {
                console.error('Erro ao buscar profissionais:', err);
                // Se a tabela não existir, retornar dados de exemplo
                const exemploProfissionais = [
                    {
                        id: 1,
                        nome: 'Carla Silva',
                        especialidade: 'Cabeleireira',
                        telefone: '(11) 98765-4321',
                        email: 'carla.silva@email.com',
                        cpf: '123.456.789-00',
                        comissao: '50',
                        status: 'ativo',
                        funcao: 'Cabeleireira'
                    },
                    {
                        id: 2,
                        nome: 'Rogério Santos',
                        especialidade: 'Barbeiro',
                        telefone: '(11) 97654-3210',
                        email: 'rogerio.santos@email.com',
                        cpf: '987.654.321-00',
                        comissao: '40',
                        status: 'ativo',
                        funcao: 'Barbeiro'
                    },
                    {
                        id: 3,
                        nome: 'Amanda Costa',
                        especialidade: 'Manicure',
                        telefone: '(11) 96543-2109',
                        email: 'amanda.costa@email.com',
                        cpf: '456.789.123-00',
                        comissao: '45',
                        status: 'ferias',
                        funcao: 'Manicure'
                    }
                ];
                
                res.json(exemploProfissionais);
            } else {
                res.json(rows);
            }
        });
    });
    
    // Buscar profissional por ID
    basicProfissionaisRouter.get('/:id', (req, res) => {
        const { id } = req.params;
        
        db.get('SELECT * FROM profissionais WHERE id = ?', [id], (err, row) => {
            if (err) {
                console.error('Erro ao buscar profissional:', err);
                // Dados de exemplo se houver erro
                const exemploProfissionais = {
                    1: {
                        id: 1,
                        nome: 'Carla Silva',
                        especialidade: 'Cabeleireira',
                        telefone: '(11) 98765-4321',
                        email: 'carla.silva@email.com',
                        cpf: '123.456.789-00',
                        comissao: '50',
                        status: 'ativo',
                        funcao: 'Cabeleireira',
                        data_nascimento: '1985-03-15',
                        genero: 'Feminino',
                        data_admissao: '2020-01-15'
                    },
                    2: {
                        id: 2,
                        nome: 'Rogério Santos',
                        especialidade: 'Barbeiro',
                        telefone: '(11) 97654-3210',
                        email: 'rogerio.santos@email.com',
                        cpf: '987.654.321-00',
                        comissao: '40',
                        status: 'ativo',
                        funcao: 'Barbeiro'
                    },
                    3: {
                        id: 3,
                        nome: 'Amanda Costa',
                        especialidade: 'Manicure',
                        telefone: '(11) 96543-2109',
                        email: 'amanda.costa@email.com',
                        cpf: '456.789.123-00',
                        comissao: '45',
                        status: 'ferias',
                        funcao: 'Manicure'
                    }
                };
                
                const profissional = exemploProfissionais[id];
                
                if (profissional) {
                    res.json(profissional);
                } else {
                    res.status(404).json({ error: 'Profissional não encontrado' });
                }
            } else if (row) {
                res.json(row);
            } else {
                res.status(404).json({ error: 'Profissional não encontrado' });
            }
        });
    });
    
    // Criar profissional
    basicProfissionaisRouter.post('/', (req, res) => {
        const profissional = req.body;
        
        // Validação básica
        if (!profissional.nome) {
            return res.status(400).json({ error: 'Nome é obrigatório' });
        }
        
        const sql = `
            INSERT INTO profissionais (
                nome, especialidade, telefone, email, cpf, comissao, 
                status, funcao, data_cadastro
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
        `;
        
        const params = [
            profissional.nome,
            profissional.especialidade || '',
            profissional.telefone || '',
            profissional.email || '',
            profissional.cpf || '',
            profissional.comissao || 0,
            profissional.status || 'ativo',
            profissional.funcao || profissional.especialidade || '',
        ];
        
        db.run(sql, params, function(err) {
            if (err) {
                console.error('Erro ao criar profissional:', err);
                // Retornar sucesso simulado se der erro
                const novoProfissional = {
                    id: Math.floor(Math.random() * 1000) + 100,
                    ...profissional,
                    status: 'ativo',
                    data_cadastro: new Date().toISOString()
                };
                res.status(201).json(novoProfissional);
            } else {
                // Buscar o profissional criado
                db.get('SELECT * FROM profissionais WHERE id = ?', [this.lastID], (err, row) => {
                    if (err) {
                        const novoProfissional = {
                            id: this.lastID,
                            ...profissional,
                            status: 'ativo',
                            data_cadastro: new Date().toISOString()
                        };
                        res.status(201).json(novoProfissional);
                    } else {
                        res.status(201).json(row);
                    }
                });
            }
        });
    });
    
    // Atualizar profissional
    basicProfissionaisRouter.put('/:id', (req, res) => {
        const { id } = req.params;
        const profissional = req.body;
        
        // Verificar se existe
        db.get('SELECT id FROM profissionais WHERE id = ?', [id], (err, row) => {
            if (err || !row) {
                return res.status(404).json({ error: 'Profissional não encontrado' });
            }
            
            const fields = [];
            const values = [];
            
            // Adicionar campos dinamicamente
            if (profissional.nome !== undefined) {
                fields.push('nome = ?');
                values.push(profissional.nome);
            }
            if (profissional.especialidade !== undefined) {
                fields.push('especialidade = ?');
                values.push(profissional.especialidade);
            }
            if (profissional.telefone !== undefined) {
                fields.push('telefone = ?');
                values.push(profissional.telefone);
            }
            if (profissional.email !== undefined) {
                fields.push('email = ?');
                values.push(profissional.email);
            }
            if (profissional.comissao !== undefined) {
                fields.push('comissao = ?');
                values.push(profissional.comissao);
            }
            if (profissional.status !== undefined) {
                fields.push('status = ?');
                values.push(profissional.status);
            }
            
            if (fields.length === 0) {
                return res.status(400).json({ error: 'Nenhum campo para atualizar' });
            }
            
            values.push(id);
            
            const sql = `UPDATE profissionais SET ${fields.join(', ')} WHERE id = ?`;
            
            db.run(sql, values, function(err) {
                if (err) {
                    console.error('Erro ao atualizar profissional:', err);
                    // Retornar sucesso simulado
                    res.json({
                        id: id,
                        ...profissional,
                        updated: true
                    });
                } else {
                    // Buscar profissional atualizado
                    db.get('SELECT * FROM profissionais WHERE id = ?', [id], (err, row) => {
                        if (err) {
                            res.json({
                                id: id,
                                ...profissional,
                                updated: true
                            });
                        } else {
                            res.json(row);
                        }
                    });
                }
            });
        });
    });
    
    // Inativar profissional (soft delete)
    basicProfissionaisRouter.delete('/:id', (req, res) => {
        const { id } = req.params;
        
        const sql = 'UPDATE profissionais SET status = "inativo" WHERE id = ?';
        
        db.run(sql, [id], function(err) {
            if (err) {
                console.error('Erro ao inativar profissional:', err);
                // Retornar sucesso simulado
                res.json({ 
                    message: 'Profissional inativado com sucesso',
                    id: id,
                    status: 'inativo'
                });
            } else {
                res.json({ 
                    message: 'Profissional inativado com sucesso',
                    id: id,
                    status: 'inativo',
                    changes: this.changes
                });
            }
        });
    });
    
    // Reativar profissional
    basicProfissionaisRouter.patch('/:id/reativar', (req, res) => {
        const { id } = req.params;
        
        const sql = 'UPDATE profissionais SET status = "ativo" WHERE id = ?';
        
        db.run(sql, [id], function(err) {
            if (err) {
                console.error('Erro ao reativar profissional:', err);
                res.json({ 
                    message: 'Profissional reativado com sucesso',
                    id: id,
                    status: 'ativo'
                });
            } else {
                res.json({ 
                    message: 'Profissional reativado com sucesso',
                    id: id,
                    status: 'ativo'
                });
            }
        });
    });
    
    // Listar profissionais ativos
    basicProfissionaisRouter.get('/ativos', (req, res) => {
        db.all('SELECT id, nome, especialidade, telefone, email, funcao, comissao FROM profissionais WHERE status = "ativo" ORDER BY nome ASC', (err, rows) => {
            if (err) {
                console.error('Erro ao buscar profissionais ativos:', err);
                // Dados de exemplo
                res.json([
                    {
                        id: 1,
                        nome: 'Carla Silva',
                        especialidade: 'Cabeleireira',
                        telefone: '(11) 98765-4321',
                        email: 'carla.silva@email.com',
                        funcao: 'Cabeleireira',
                        comissao: '50'
                    },
                    {
                        id: 2,
                        nome: 'Rogério Santos',
                        especialidade: 'Barbeiro',
                        telefone: '(11) 97654-3210',
                        email: 'rogerio.santos@email.com',
                        funcao: 'Barbeiro',
                        comissao: '40'
                    }
                ]);
            } else {
                res.json(rows);
            }
        });
    });
    
    app.use('/api/profissionais', basicProfissionaisRouter);
    console.log('✅ Rotas básicas de profissionais criadas');
}

// ===== SERVIR FRONTEND =====
const frontendPath = path.join(__dirname, '../frontend');
app.use(express.static(frontendPath));
console.log(`📁 Frontend servido de: ${frontendPath}`);

// Rota para páginas HTML
app.get('*', (req, res, next) => {
    if (req.path.startsWith('/api/')) return next();
    
    const requestedPath = req.path === '/' ? 'dashboard.html' : req.path;
    const htmlPath = path.join(__dirname, '../frontend/html', requestedPath);
    
    if (fs.existsSync(htmlPath) && htmlPath.endsWith('.html')) {
        console.log(`📄 Servindo página: ${requestedPath}`);
        res.sendFile(htmlPath);
    } else {
        // Fallback para dashboard
        const dashboardPath = path.join(__dirname, '../frontend/html/dashboard.html');
        if (fs.existsSync(dashboardPath)) {
            console.log(`📄 Fallback para dashboard: ${requestedPath} → dashboard.html`);
            res.sendFile(dashboardPath);
        } else {
            console.log(`❌ Página não encontrada: ${requestedPath}`);
            res.status(404).send(`
                <h1>Página não encontrada</h1>
                <p>A página solicitada não existe.</p>
                <a href="/">Voltar ao início</a>
            `);
        }
    }
});

// ===== INICIAR SERVIDOR =====
app.listen(PORT, () => {
    console.log(`
    🚀 MY SALON - SISTEMA INICIADO
    ==============================
    📡 Servidor:       http://localhost:${PORT}
    📊 Dashboard:      http://localhost:${PORT}/html/dashboard.html
    👥 Clientes:       http://localhost:${PORT}/html/clientes.html
    👤 Profissionais:  http://localhost:${PORT}/html/profissionais.html
    ✂️  Serviços:       http://localhost:${PORT}/html/servicos.html
    📅 Agenda:         http://localhost:${PORT}/html/agenda.html
    🧪 Health Check:   http://localhost:${PORT}/api/health
    👤 API Clientes:   http://localhost:${PORT}/api/clientes
    👨‍🔧 API Profissionais: http://localhost:${PORT}/api/profissionais
    ✂️  API Serviços:    http://localhost:${PORT}/api/servicos
    ==============================
    `);
    console.log('✅ Backend: Node.js + Express + SQLite');
    console.log('✅ Frontend: HTML/CSS/JS Vanilla');
    console.log('✅ Banco: SQLite com 30 tabelas');
    console.log('💡 Dica: Acesse http://localhost:3000/html/profissionais.html para testar');
});